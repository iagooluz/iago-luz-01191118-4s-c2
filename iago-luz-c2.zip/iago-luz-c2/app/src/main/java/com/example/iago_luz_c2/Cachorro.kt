package com.example.iago_luz_c2

data class Cachorro(val id: Int, val raca: String, val precoMedio: Int, val indicadorCrianca: Boolean) {


}