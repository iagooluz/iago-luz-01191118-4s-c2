package com.example.iago_luz_c2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Tela3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela3)
    }
}