package com.example.iago_luz_c2

import retrofit2.Call
import retrofit2.http.*
interface ApiCachorro {

    // Método HTTP "Get" e a URI é "/filmes"
    @GET("cachorros")
    fun get(): Call<List<Cachorro>>
    // O retorno (corpo da resposta) desse EndPoint, em caso de sucesso é uma List de Filme

    // Método HTTP "Get" e a URI é "/filmes/{id}"
    @GET("cachorros/{id}") // "/{id}" -> é um Path Param
    fun get(@Path("id") id:Int): Call<Cachorro>
    // O retorno (corpo da resposta) desse EndPoint, em caso de sucesso é um Filme

    // Método HTTP "Delete" e a URI é "/filmes/{id}"
    @DELETE("filmes/{id}")
    fun delete(@Path("id") id:Int): Call<Void>
    // neste caso dizemos que não vamos pegar o corpo da resposta (por isso "Void")

    @POST("filmes")
    fun post(@Body novoCachorro: Cachorro): Call<Cachorro>
    // @Body indica que estamos enviando um Corpo de Requisição
}