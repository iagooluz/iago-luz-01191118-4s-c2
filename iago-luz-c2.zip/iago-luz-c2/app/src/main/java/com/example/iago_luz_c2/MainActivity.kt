package com.example.iago_luz_c2

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.concurrent.ThreadLocalRandom

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun irTela2(view: View) {

        val tela2 = Intent(this, Tela2::class.java)

        // putExtra(1,2) passa, envia informações para a Activity da Intent
        // 1 -> NOME do dado (nome que quiser dar)
        // 2 -> VALOR do dado (pode ser de praticamente qualquer tipo, até uma Data Class)
        tela2.putExtra("id", 1)
        tela2.putExtra("raça", "bulldog")
        tela2.putExtra("preco_medio", 12)
        tela2.putExtra("indicador_crianca", true)


        val layoutLista: LinearLayout = findViewById(R.id.layout_lista)

        // usando o object para pegar a instância do objeto que invoca os EndPoints
        val apiCachorro = ApiCachorroConexao.criar()

        // .enqueue() abre um processo ASSÍNCRONO (ou seja, paralelo, não "trava" a tela)
        apiCachorro.get().enqueue(object : Callback<List<Cachorro>> { // retrofit2.Callback

            // onResponse é executando se chamada for feita com sucesso
            override fun onResponse(call: Call<List<Cachorro>>, response: Response<List<Cachorro>>) {

                // response.body() -> obtém o corpo da resposta
                response.body()?.forEach {

                    // criando uma nova TextView
                    val cachorroNovo = TextView(baseContext)
                    cachorroNovo.text = "Id: ${it.id} - raca: ${it.raca} - precoMedio: ${it.precoMedio} - indicador: ${it.indicadorCrianca}"
                    cachorroNovo.setTextColor(Color.parseColor("#9911AA"))

                    // adicionando a nova TextView no LinearLayout
                    layoutLista.addView(cachorroNovo)
                }
            }

            // onFailure é executado se houver erro na chamada
            override fun onFailure(call: Call<List<Cachorro>>, t: Throwable) {
                Toast.makeText(baseContext, "Erro na chamada: ${t.message!!}", Toast.LENGTH_SHORT).show()
            }

        })



        fun criarCachorro(view: View) {
            val apiCachorro = ApiCachorroConexao.criar()

            val idQualquer = "Cachorro ${ThreadLocalRandom.current().nextInt(0, 1000)}"
            val racaQualquer = ThreadLocalRandom.current().nextDouble(0.0, 100_000.0)
            val precoQualquer = ThreadLocalRandom.current().nextDouble(0.0, 100_000.0)
            val indicadorQuaquer =ThreadLocalRandom.current().nextDouble(0.0, 100_000.0)
            val cachorroQualquer = Cachorro(1, raca = "Bulldog", precoMedio = 10, indicadorCrianca = true)

            val cachorroNovo: TextView = findViewById(R.id.number_id_cachorro)

            apiCachorro.post(cachorroQualquer).enqueue(object : Callback<Cachorro> {
                override fun onResponse(call: Call<Cachorro>, response: Response<Cachorro>) {
                    if (response.code() == 201) {
                        val cachorroCriado = response.body()
                        cachorroNovo.text = "Cachorro ${cachorroCriado?.id} Cão cadastrado com sucesso"
                    } else {
                        cachorroNovo.text = "Falha ao criar o filme: ${response.errorBody()!!}"
                        // errorBody() traz o corpo em caso de Status de erro (4xx ou 5xx)
                    }
                }

                override fun onFailure(call: Call<Cachorro>, t: Throwable) {
                    Toast.makeText(baseContext, "Erro na chamada: ${t.message!!}", Toast.LENGTH_SHORT).show()
                }
            })

        }

        startActivity(tela2)

    }


    fun irTela3(view: View) {

        val Tela3 = Intent(this, Tela3::class.java)


        startActivity(Tela3)


    }
}